In order to utelize this script, you most extract the zip file, and make sure that the file beep.ogg is in the saim foolder as the program.
your also welcome to replace this file with any .ogg file that you want.
