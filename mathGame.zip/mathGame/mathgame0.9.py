#Author: Amir Amini
import random
from inputimeout import inputimeout, TimeoutOccurred
import pygame  # Import the pygame library

# Initialize pygame mixer
pygame.mixer.init()

# Function to play beep sound
def play_beep():
    # Load the sound file (ensure the sound file is in the same directory as your script)
    beep_sound =    pygame.mixer.Sound("beep.ogg")
    beep_sound.play()

def generate_question():
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    operator = random.choice(['+', '-', '*'])
    question = f"What is {num1} {operator} {num2}? "
    if operator == '+':
        answer = num1 + num2
    elif operator == '-':
        answer = num1 - num2
    else:
        answer = num1 * num2
    
    return question, answer

def run_quiz():
    score = 0
    for _ in range(10):
        question, answer = generate_question()
        try:
            input_str = inputimeout(prompt=question, timeout=30)
            if input_str.strip() == "":  # Check if input is not empty
                print("You didn't enter anything!")
                raise ValueError
            user_answer = int(input_str)
            if user_answer == answer:
                print("✅ Correct!")
                play_beep()  # Play beep sound
                score += 1
            else:
                print("❌ Incorrect!")
                print(f"The correct answer was {answer}")
        except TimeoutOccurred:
            print("nTime's up! You get an extra 30 seconds but for half a point.")
            try:
                input_str = inputimeout(prompt=question, timeout=30)
                if input_str.strip() == "":
                    print("You didn't enter anything!")
                    raise ValueError
                user_answer = int(input_str)
                if user_answer == answer:
                    print("✅ Correct, but half point!")
                    play_beep()  # Play a beep sound, possibly at a different frequency or duration for half points
                    score += 0.5
                else:
                    print("❌ Incorrect!")
                    print(f"The correct answer was {answer}")
            except TimeoutOccurred:
                print("❌ No answer provided again!")
                print(f"The correct answer was {answer}")
        except ValueError:
            print("Invalid input. Please enter a number.")
    
    print(f"\nYour score is: {score} out of 10. 🎉")

def main():
    start = input("Do you want to start the program? (yes/no): ").lower()
    if start == 'yes':
        run_quiz()
    else:
        print("Okay, maybe next time!")

main()


import random
from inputimeout import inputimeout, TimeoutOccurred
import pygame
import time

# Initialize pygame mixer
pygame.mixer.init()

# Function to play beep sound
def play_beep():
    # Load the sound file (ensure the sound file is in the same directory as your script)
    beep_sound = pygame.mixer.Sound("beep.ogg")
    beep_sound.play()

def generate_question():
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    operator = random.choice(['+', '-', '*'])
    question = f"What is {num1} {operator} {num2}? "
    if operator == '+':
        answer = num1 + num2
    elif operator == '-':
        answer = num1 - num2
    else:
        answer = num1 * num2
    
    return question, answer

def run_quiz():
    score = 0
    for _ in range(10):
        question, answer = generate_question()
        try:
            input_str = inputimeout(prompt=question, timeout=30)
            if input_str.strip() == "":  # Check if input is not empty
                print("You didn't enter anything!")
                raise ValueError
            if input_str.strip().lower() == "hard":  # If user enters "hard"
                print("You found it hard. Here's another one.")
                time.sleep(1)  # Introduce a delay before presenting the next question
                continue  # Skip counting this question
            user_answer = int(input_str)
            if user_answer == answer:
                print("✅ Correct!")
                play_beep()  # Play beep sound
                score += 1
            else:
                print("❌ Incorrect!")
                print(f"The correct answer was {answer}")
        except TimeoutOccurred:
            print("\nTime's up! You get an extra 30 seconds but for half a point.")
            try:
                input_str = inputimeout(prompt=question, timeout=30)
                if input_str.strip() == "":
                    print("You didn't enter anything!")
                    raise ValueError
                user_answer = int(input_str)
                if user_answer == answer:
                    print("✅ Correct, but half point!")
                    play_beep()  # Play a beep sound
                    score += 0.5
                else:
                    print("❌ Incorrect!")
                    print(f"The correct answer was {answer}")
            except TimeoutOccurred:
                print("❌ No answer provided again!")
                print(f"The correct answer was {answer}")
        except ValueError:
            print("Invalid input. Please enter a number.")
    
    print(f"\nYour score is: {score} out of 10. 🎉")

def main():
    start = input("Do you want to start the program? (yes/no): ").lower()
    if start == 'yes':
        run_quiz()
    else:
        print("Okay, maybe next time!")

main()
